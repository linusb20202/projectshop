@extends('layouts.homenew')
@section('content')
<div class="">asdasd</div>

@endsection
