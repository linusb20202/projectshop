/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'ru', {
	label: 'Форматирование',
	panelTitle: 'Форматирование',
	tag_address: 'Адрес',
	tag_div: 'Обычное (div)',
	tag_h1: 'Заголовок 1',
	tag_h2: 'Заголовок 2',
	tag_h3: 'Заголовок 3',
	tag_h4: 'Заголовок 4',
	tag_h5: 'Заголовок 5',
	tag_h6: 'Заголовок 6',
	tag_p: 'Обычное',
	tag_pre: 'Моноширинное'
} );
