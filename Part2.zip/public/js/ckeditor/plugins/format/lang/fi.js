/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'fi', {
	label: 'Muotoilu',
	panelTitle: 'Muotoilu',
	tag_address: 'Osoite',
	tag_div: 'Normaali (DIV)',
	tag_h1: 'Otsikko 1',
	tag_h2: 'Otsikko 2',
	tag_h3: 'Otsikko 3',
	tag_h4: 'Otsikko 4',
	tag_h5: 'Otsikko 5',
	tag_h6: 'Otsikko 6',
	tag_p: 'Normaali',
	tag_pre: 'Muotoiltu'
} );
