/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'sr', {
	label: 'Формат',
	panelTitle: 'Формат пасуса',
	tag_address: 'Адреса',
	tag_div: 'Нормално (DIV)',
	tag_h1: 'Наслов 1',
	tag_h2: 'Наслов 2',
	tag_h3: ' Наслов 3',
	tag_h4: 'Наслов 4',
	tag_h5: 'Наслов 5',
	tag_h6: 'Наслов 6',
	tag_p: 'Нормално',
	tag_pre: 'Форматирано'
} );
