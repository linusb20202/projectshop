/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'az', {
	label: 'Format',
	panelTitle: 'Abzasın formatı',
	tag_address: 'Ünvan',
	tag_div: 'Normal (DIV)',
	tag_h1: 'Başlıq 1',
	tag_h2: 'Başlıq 2',
	tag_h3: 'Başlıq 3',
	tag_h4: 'Başlıq 4',
	tag_h5: 'Başlıq 5',
	tag_h6: 'Başlıq 6',
	tag_p: 'Normal',
	tag_pre: 'Formatı saxla'
} );
