/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'ug', {
	label: 'پىچىم',
	panelTitle: 'پىچىم',
	tag_address: 'ئادرېس',
	tag_div: 'ئابزاس (DIV)',
	tag_h1: 'ماۋزۇ 1',
	tag_h2: 'ماۋزۇ 2',
	tag_h3: 'ماۋزۇ 3',
	tag_h4: 'ماۋزۇ 4',
	tag_h5: 'ماۋزۇ 5',
	tag_h6: 'ماۋزۇ 6',
	tag_p: 'ئادەتتىكى',
	tag_pre: 'تىزىلغان پىچىم'
} );
