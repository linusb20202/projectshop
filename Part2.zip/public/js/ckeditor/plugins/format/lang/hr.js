/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'hr', {
	label: 'Format',
	panelTitle: 'Format paragrafa',
	tag_address: 'Adresa',
	tag_div: 'Normalno (DIV)',
	tag_h1: 'Naslov 1',
	tag_h2: 'Naslov 2',
	tag_h3: 'Naslov 3',
	tag_h4: 'Naslov 4',
	tag_h5: 'Naslov 5',
	tag_h6: 'Naslov 6',
	tag_p: 'Normalno',
	tag_pre: 'Formatirano'
} );
